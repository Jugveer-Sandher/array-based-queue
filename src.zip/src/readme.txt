Youtube Link for Presentation video:
https://youtu.be/ayOGEcjFqGA
Thank you!